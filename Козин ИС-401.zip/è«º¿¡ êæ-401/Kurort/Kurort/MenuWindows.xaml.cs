﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace Kurort
{
    /// <summary>
    /// Логика взаимодействия для MenuWindows.xaml
    /// </summary>
    public partial class MenuWindows : Window
    { 
        //Таймер сессии
        DispatcherTimer timer;
        public MenuWindows()
        {
            InitializeComponent();
            timer = new DispatcherTimer();
            timer.Interval = TimeSpan.FromSeconds(1);
            timer.Tick += Timer_Tick;
            timer.Start();
            //Вывод текущего пользователя в системе
            surnameTxt.Text = curUser.Surname;
            nameTxt.Text = curUser.Name;
            lastnameTxt.Text = curUser.Lastname;
            imageProfile.ImageSource = new BitmapImage(new Uri(curUser.Image));
            roleTxt.Text = curUser.Role;
            //В зависимости от роли будут показаны определённые кнопки
            if (roleTxt.Text == "Старший смены")
                addTovarBtn.Visibility = Visibility.Visible;
            if (roleTxt.Text == "Администратор")
            {
                adminPanel.Visibility = Visibility.Visible;
                addTovarBtn.Visibility = Visibility.Visible;
            }
        }

        private void Timer_Tick(object? sender, EventArgs e)
        {
            if (GlobalTimer.Seconds <= 0)
            {
                timer.Stop();
                GlobalTimer.Reset();
                MainWindow main = new MainWindow();
                main.Left = this.Left;
                main.Top = this.Top;
                main.Show();
                this.Close();
            }
            if (GlobalTimer.Seconds == 60)
            {
                GlobalTimer.MessageExit();
            }
            GlobalTimer.Seconds = GlobalTimer.Seconds - 1;
            TimeSpan time = TimeSpan.FromSeconds(GlobalTimer.Seconds);
            timerTxt.Text = time.ToString(@"hh\:mm\:ss");
        }

        private void closeBtn_Click(object sender, RoutedEventArgs e)
        {
            timer.Stop();
            this.Close();
        }

        private void Border_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (e.LeftButton == MouseButtonState.Pressed)
                DragMove();
        }
        //Метод для выхода из учётной записи
        private void exitBtn_Click(object sender, RoutedEventArgs e)
        {
            timer.Stop();
            GlobalTimer.Reset();
            MainWindow mainWindow = new MainWindow();
            mainWindow.WindowStartupLocation = WindowStartupLocation.Manual;
            mainWindow.Left = this.Left;
            mainWindow.Top = this.Top;
            mainWindow.Show();
            this.Close();
        }
        //Кнопка перехода в окно Истории входа
        private void historyBtn_Click(object sender, RoutedEventArgs e)
        {
            timer.Stop();
            HistoryWindow historyWindow = new HistoryWindow();  
            historyWindow.Left = this.Left;
            historyWindow.Top = this.Top;
            historyWindow.Show();
            this.Close();
        }
        //Кнопка перехода в окно Формирования заказа
        private void addBtn_Click(object sender, RoutedEventArgs e)
        {
            timer.Stop();
            AddOrderWin add = new AddOrderWin();
            add.Left = this.Left;
            add.Top = this.Top;
            add.Show();
            this.Close();
        }
    }
}
