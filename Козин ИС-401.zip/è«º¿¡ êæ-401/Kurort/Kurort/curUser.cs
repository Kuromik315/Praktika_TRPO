﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kurort
{
    public static class curUser
    {
        public static string Role { get; set; }
        public static int ID { get; set; }
        public static string Name { get; set; }
        public static string Surname { get; set; }
        public static string Email { get; set; }
        public static string Lastname { get; set; }
        public static string Image { get {
                if (File.Exists(AppDomain.CurrentDomain.BaseDirectory + "\\Resources\\" + $"{Surname}.jpeg"))
                    return AppDomain.CurrentDomain.BaseDirectory + "\\Resources\\" + $"{Surname}.jpeg";
                return AppDomain.CurrentDomain.BaseDirectory + "\\Resources\\" + $"{Surname}.jpg";
            }}
    }
}
