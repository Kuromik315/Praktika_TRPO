﻿using Kurort.Entity;
using Microsoft.EntityFrameworkCore;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Captcha;
using System.Windows.Threading;

namespace Kurort
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        DispatcherTimer timerCapt;
        public MainWindow()
        {
            InitializeComponent();
            isCapthca = false;
        }

        private void Border_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ButtonState == MouseButtonState.Pressed)
            {
                DragMove();
            }
        }

        private void closeBtn_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
        bool isCapthca;
        int coutinput;

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            //Проверка введеных пользователем данных
            string login = loginTxt.Text;
            string pass = passTxt.Password;
            KurortDB kurortDB = new KurortDB();
            foreach (var user in App.db.Users.Include(x => x.IdRoleNavigation))
            {
                if (user.Login == login)
                {
                    if (user.Password == pass)
                    {
                        //Если логин и пароль совпали записываем данные текущего пользователя в спецаильный класс
                        //Данные будут использованы в дальнейшем для работы приложения
                        //Также происходит запись входа в БД 
                        HistoryJoin joinu = new HistoryJoin();
                        joinu.Login = login;
                        joinu.IdUser = user.IdUser;
                        joinu.Status = "Успешно";
                        joinu.DateInput = DateTime.Now;
                        kurortDB.HistoryJoins.Add(joinu);
                        kurortDB.SaveChanges();
                        curUser.ID = user.IdUser;
                        curUser.Surname = user.Surname;
                        curUser.Name = user.Name;
                        curUser.Lastname = user.Lastname;
                        curUser.Email = user.Login;
                        curUser.Role = user.IdRoleNavigation.Name;
                        MenuWindows menu = new MenuWindows();
                        menu.Left = this.Left;
                        menu.Top = this.Top;
                        menu.Show();
                        this.Close();
                        return;
                    }
                    //Запись неудачного входа в БД
                    HistoryJoin join = new HistoryJoin();
                    join.Login = login;
                    join.IdUser = user.IdUser;
                    join.Status = "Неуспешно";
                    join.DateInput = DateTime.Now;
                    kurortDB.HistoryJoins.Add(join);
                    kurortDB.SaveChanges();
                    MessageBox.Show("Пароль неверный!", "Ошибка входа", MessageBoxButton.OK, MessageBoxImage.Error);
                    coutinput = coutinput + 1;
                    if (coutinput >= 2)
                    {
                        //При более двух неудачных попыток входа появится капча
                        GenerateCapt();
                        isCapthca = true;
                        stackCapt.Visibility = Visibility.Visible;
                        inputBtn.IsEnabled = false;
                    }
                    return;
                }
            }
            MessageBox.Show("Пользователь не найден", "Внимание!", MessageBoxButton.OK, MessageBoxImage.Error);
            coutinput = coutinput + 1;
            if (coutinput >= 2)
            {
                //При более двух неудачных попыток входа появится капча
                GenerateCapt();
                isCapthca = true;
                stackCapt.Visibility = Visibility.Visible;
                inputBtn.IsEnabled = false;
            }
            return;
        }
        string checkText;
        //Метод для генерации текста для капчи
        public void GenerateText()
        {
            string text = "";
            string chars = "QWERTYUIOPASDFGHJKZXCVBNMqwertyuiopasdfghjklzxcvbnm1234567890";
            Random rd = new Random();
            for (int i = 0; i < 5; i++)
            {
                text = text + chars[rd.Next(chars.Length)];
            }
            checkText = text;
        }
        //Генерация капчи и вывод её в Image
        public void GenerateCapt()
        {
            GenerateText();
            captImg.Source = CaptchaGenerate.GenerateCap(150, 100, checkText);
        }
        int countCapt;
        //Метод для проверки правильности введеной капчи пользователем
        private void checkBtn_Click(object sender, RoutedEventArgs e)
        {
            if (captTxt.Text == checkText)
            {
                inputBtn.IsEnabled = true;
                stackCapt.Visibility = Visibility.Collapsed;
                coutinput = 0;
                isCapthca = false;
                return;
            }
            countCapt = countCapt + 1;
            if (countCapt >= 2)
            {
                timerCapt = new DispatcherTimer();
                timerCapt.Interval = TimeSpan.FromSeconds(10);
                timerCapt.Tick += TimerCapt_Tick;
                timerCapt.Start();
                checkBtn.IsEnabled = false;
                MessageBox.Show("Тайм-аут 10 секунд", "Внимание", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
            GenerateCapt();
        }
        //Используется для блокировки входа на 10сек
        private void TimerCapt_Tick(object? sender, EventArgs e)
        {
            timerCapt.Stop();
            checkBtn.IsEnabled = true;
        }
        //Генерация новой капчи
        private void refreshBtn_Click(object sender, RoutedEventArgs e)
        {
            GenerateCapt();
        }
    }
}