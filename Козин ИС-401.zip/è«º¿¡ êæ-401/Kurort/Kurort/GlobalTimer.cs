﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Threading;

namespace Kurort
{
    public static class GlobalTimer
    {
        public static int Seconds { get; set; } = 120;
        public static void Reset()
        {
            Seconds = 120;
        }
        public static void MessageExit()
        {
            MessageBox.Show("Внимание до конца сеанса осталась 1 минута", "Время сеанса", MessageBoxButton.OK, MessageBoxImage.Warning);
        }
    }
}
