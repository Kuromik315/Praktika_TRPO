﻿using System;
using System.Collections.Generic;

namespace Kurort.Entity;

public partial class Service
{
    public int IdService { get; set; }

    public string Name { get; set; } = null!;

    public string CodeService { get; set; } = null!;

    public decimal Price { get; set; }

    public virtual ICollection<ServicesToOrder> ServicesToOrders { get; set; } = new List<ServicesToOrder>();
}
