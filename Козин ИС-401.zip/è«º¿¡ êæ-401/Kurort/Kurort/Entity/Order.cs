﻿using System;
using System.Collections.Generic;

namespace Kurort.Entity;

public partial class Order
{
    public int IdOrder { get; set; }

    public string CodeOrder { get; set; } = null!;

    public DateTime CreateDate { get; set; }

    public int ClientCode { get; set; }

    public int IdStatus { get; set; }

    public DateTime? ClosedDate { get; set; }

    public int RentalTime { get; set; }

    public TimeOnly CreateTime { get; set; }

    public virtual Client ClientCodeNavigation { get; set; } = null!;

    public virtual Status IdStatusNavigation { get; set; } = null!;

    public virtual ICollection<ServicesToOrder> ServicesToOrders { get; set; } = new List<ServicesToOrder>();
}
