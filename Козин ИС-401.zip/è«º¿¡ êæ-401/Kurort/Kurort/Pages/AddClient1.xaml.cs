﻿using Kurort.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace Kurort.Pages
{
    /// <summary>
    /// Логика взаимодействия для AddClient1.xaml
    /// </summary>
    public partial class AddClient1 : Page
    {
        public AddClient1()
        {
            InitializeComponent();
            App.addClient = new Client();
        }

        private void nextBtn_Click(object sender, RoutedEventArgs e)
        {
            if (!Check())
                return;
            //Создание нового клиента
            App.addClient.Surname = txtSurname.Text;
            App.addClient.Name = txtName.Text;
            App.addClient.Lastname = txtlastname.Text;
            App.addClient.Birthday = DateOnly.FromDateTime(birthdayTxt.SelectedDate.Value);
            App.addClient.Address = txtAdress.Text;
            App.addClient.Passport = long.Parse(txtPass.Text);
            AddClient2 client2 = new AddClient2();
            NavigationService.Navigate(client2);
        }
        //Метод проверки данных
        bool Check()
        {
            foreach (var item in stackClient.Children)
            {
                if (item is TextBox)
                {
                    TextBox textBox = (TextBox)item;
                    if (textBox.Text == ""|| textBox.Text == " "|| string.IsNullOrWhiteSpace(textBox.Text))
                    {
                        MessageBox.Show("Не все поля заполнены", "Ошибка создания", MessageBoxButton.OK, MessageBoxImage.Warning);
                        return false;
                    }
                    if (textBox.Name == "txtPass")
                    {
                        long a;
                        if (!long.TryParse(textBox.Text, out a))
                        {
                            MessageBox.Show("Поле паспорт заполнено неверно", "Ошибка создания", MessageBoxButton.OK, MessageBoxImage.Warning);
                            return false;
                        }
                        if (textBox.Text.Length != 10)
                        {
                            MessageBox.Show("Поле паспорт заполнено неверно", "Ошибка создания", MessageBoxButton.OK, MessageBoxImage.Warning);
                            return false;
                        }
                    }
                }
                if (item is DatePicker)
                {
                    DatePicker datePicker = (DatePicker)item;
                    if (datePicker.SelectedDate == null)
                    {
                        MessageBox.Show("Не выбрана дата рождения", "Ошибка создания", MessageBoxButton.OK, MessageBoxImage.Warning);
                        return false;
                    }
                }
            }
            return true;
        }
    }
}
