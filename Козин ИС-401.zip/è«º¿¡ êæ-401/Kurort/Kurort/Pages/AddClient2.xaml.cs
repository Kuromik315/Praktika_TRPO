﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace Kurort.Pages
{
    /// <summary>
    /// Логика взаимодействия для AddClient2.xaml
    /// </summary>
    public partial class AddClient2 : Page
    {
        public AddClient2()
        {
            InitializeComponent();

        }

        private void addBtn_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (!Check())
                    return;
                //Ввод оставшихся данных и запись нового клиента в бд
                App.addClient.Email = txtEmail.Text;
                App.addClient.Password = txtPass.Text;
                App.db.Clients.Add(App.addClient);
                App.db.SaveChanges();
                MessageBox.Show("Клиент добавлен!", "Успех!", MessageBoxButton.OK, MessageBoxImage.Information);
                ClientAdd window = (ClientAdd)Window.GetWindow(this);
                window.timer.Stop();
                window.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Возникла ошибка: {ex.Message}", "Внимание", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
        }
        //возврат на предыщую страницу
        private void backBtn_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.GoBack();
        }
        //Метод проверки данных 
        bool Check()
        {
            if (txtEmail.Text == "" || txtEmail.Text == " " || string.IsNullOrWhiteSpace(txtEmail.Text))
            {
                MessageBox.Show("Заполните поле email!", "Внимание!", MessageBoxButton.OK, MessageBoxImage.Warning);
                return false;
            }
            if (txtPass.Text == "" || txtPass.Text == " " || string.IsNullOrWhiteSpace(txtPass.Text))
            {
                MessageBox.Show("Заполните поле пароль!", "Внимание!", MessageBoxButton.OK, MessageBoxImage.Warning);
                return false;
            }
            return true;
        }
    }
}
